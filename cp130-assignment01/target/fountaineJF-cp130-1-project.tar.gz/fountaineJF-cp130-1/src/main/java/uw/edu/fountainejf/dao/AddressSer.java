package uw.edu.fountainejf.dao;

public class AddressSer {

}
