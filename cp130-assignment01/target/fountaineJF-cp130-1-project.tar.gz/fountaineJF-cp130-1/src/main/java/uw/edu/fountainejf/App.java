package uw.edu.fountainejf;

import edu.uw.ext.framework.account.Account;
import edu.uw.ext.framework.account.AccountFactory;

/**
 * Hello world!
 *
 */
public class App 
{

    public static void main( String[] args )
    {


        byte[] passwordBytes  = new byte[]{98, 101, 116, 116, 101, 114, 112, 97, 115, 115, 119, 111, 114, 100};

//        Account account = this.accountFactory.newAccount("test account", 1000000, passwordBytes);
//        System.out.println(account);
//        System.out.println(account.getName() +" ::::: " + account.getBalance() + "   ::::  " + account.getPasswordHash() );
    }
}
